package com.hari.my_first_japp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstJappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstJappApplication.class, args);
	}

}
