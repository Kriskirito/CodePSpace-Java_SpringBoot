package com.hari.my_first_japp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstJappApplicationTests {

	@Test
	void contextLoads() {
	}

}
